interface Props {
    canchas: any[];
    loading: boolean;
    onEliminar: (id: number) => void;
}

export default function VistaCanchasPropietario({ canchas, loading, onEliminar }: Props) {
    return (
        <div className="animate-in slide-in-from-right-4 duration-500">
            <div className="flex justify-between items-end mb-8">
                <div>
                    <h2 className="text-3xl font-black text-[#03292e] mb-2">Mis Canchas</h2>
                    <p className="text-gray-500">Gestiona tus {canchas.length} escenarios deportivos.</p>
                </div>
                <button className="bg-[#03292e] text-white px-6 py-3 rounded-2xl font-bold hover:bg-[#0a4149] transition-all shadow-lg active:scale-95">
                    + Agregar Cancha
                </button>
            </div>

            {loading ? (
                <div className="flex flex-col items-center py-20 animate-pulse">
                    <div className="w-12 h-12 bg-gray-200 rounded-full mb-4"></div>
                    <p className="text-gray-400 font-medium">Cargando inventario...</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {canchas.map((cancha) => (
                        <div key={cancha.canchaId} className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                            <h4 className="font-black text-xl text-[#03292e] uppercase mb-1">{cancha.codigo}</h4>
                            <p className="text-[#0ed1e8] font-bold text-lg mb-4">${cancha.precioPorHora} / hora</p>
                            <div className="flex gap-3">
                                <button className="flex-1 bg-gray-100 py-3 rounded-2xl text-sm font-bold text-gray-600 hover:bg-gray-200 transition-colors">
                                    Editar
                                </button>
                                <button
                                    onClick={() => onEliminar(cancha.canchaId)}
                                    className="flex-1 bg-red-50 py-3 rounded-2xl text-sm font-bold text-red-500 hover:bg-red-100 transition-colors"
                                >
                                    Eliminar
                                </button>
                            </div>
                        </div>
                    ))}

                    {canchas.length === 0 && (
                        <div className="col-span-full py-24 text-center border-2 border-dashed border-gray-200 rounded-[3rem]">
                            <p className="text-gray-400 font-bold text-lg">No tienes canchas registradas aún.</p>
                            <p className="text-gray-300">Empieza agregando tu primera cancha arriba.</p>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
