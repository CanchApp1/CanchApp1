import api from "./api";

export type RegisterData = {
  nombre: string;
  correo: string;
  contrasena: string;
  fechaNacimiento: string;
  numeroTelefono: string;
  edad: number;
  nombrePerfil: string;
};

export const registerUsuario = async (userData: RegisterData) => {
  const response = await api.post("/auth/register", userData);
  return response.data;
};


// 1. Definimos qué enviamos para el Login
export type LoginData = {
  correo: string;
  contrasena: string;
};

// 2. Creamos la función para hacer Login
export const loginUsuario = async (credentials: LoginData) => {
  const response = await api.post("/auth/login", credentials);
  return response.data; // Esto devolverá el token que te da Spring Boot
};


// NUEVA FUNCIÓN: El registro combinado para Propietario + Establecimiento
export const registerPropietario = async (datosPropietario: any) => {
  // Según tu Swagger, este es el endpoint exacto para guardar la cancha y el usuario a la vez
  const response = await api.post('/v1/api/establecimiento', datosPropietario);
  return response.data;
};