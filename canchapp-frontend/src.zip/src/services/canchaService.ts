// src/services/canchaService.ts
import api from './api'; // Ajusta la ruta según dónde esté tu api.ts

export const obtenerCanchasPorEstablecimiento = async (establecimientoId: number) => {
    try {
        const response = await api.get(`/v1/api/cancha/establecimiento/${establecimientoId}`);
        // ¡Sacamos la lista de adentro del objectResponse!
        return response.data.objectResponse || [];
    } catch (error) {
        console.error(`Error en canchas (${establecimientoId}):`, error);
        throw error;
    }
};

export const eliminarCancha = async (canchaId: number) => {
    try {
        const response = await api.delete(`/v1/api/cancha/${canchaId}`);
        return response.data;
    } catch (error) {
        console.error("Error eliminando cancha:", error);
        throw error;
    }
};
